<?php $__env->startSection('book'); ?>
    <div class="new-book-area pb-100" style="padding: 20px;">

        <div class="container">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="section-title bt text-center pt-50 mb-30 section-title-res" >
                                <?php if(!empty($type)): ?>
                                    <h2 ><?php echo e($type); ?></h2>
                                <?php endif; ?>
                            </div>

                        </div>


                    </div>
                    <div class="tab-content">
                        <div class="tab-pane active" id="th">
                            <div class="row">

                                <?php if(!empty($preview)): ?>
                                    <?php $__currentLoopData = $preview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="col-lg-3 col-md-4 col-sm-6">
                                                <!-- single-product-start -->

                                                <div class="product-wrapper mb-40">

                                                    <div class="product-img">

                                                        <a href="<?php echo e(url('book_view/'.$book->book_id)); ?>" target="_blank">
                                                            <img src="<?php echo e('../'.$book->book_image); ?>" alt="book"  class="primary" />
                                                        </a>

                                                        <div class="quick-view">
                                                            <a class="action-view" href="<?php echo e(url('book_view/'.$book->book_id)); ?>" target="_blank"  title="Quick View">
                                                                <i class="fa fa-eye"></i>
                                                            </a>
                                                            <br>

                                                        </div>



                                                    </div>

                                                    <div class="product-details text-center">
                                                        <h4><a href="<?php echo e(url('book_view/'.$book->book_id)); ?>" target="_blank"><?php echo e($book->book_name); ?></a></h4>
                                                    </div>
                                                    <div class="text-center">
                                                        <p><?php echo e($book->author_name); ?></p>
                                                    </div>

                                                </div>
                                            </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                    <?php echo e($preview->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front_end.book_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/front_end/Books/categorical_book.blade.php ENDPATH**/ ?>