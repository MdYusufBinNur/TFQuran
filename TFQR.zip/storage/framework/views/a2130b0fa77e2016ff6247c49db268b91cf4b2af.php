<?php $__env->startSection('body'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark"></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>

                            <li class="breadcrumb-item active">Category List</li>

                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->

        <div class="content">
            <div class="container-fluid">
                <div class="row">

                </div>
                <div class="row">


                    <!-- /.col-md-6 -->
                    <div class="col-lg-12">

                        <div class="card card-dark">
                            <div class="card-header">
                                <div class="row">

                                    <div class="col-md-8">
                                        <h5 class="text-left" >
                                            CATEGORY LIST
                                            <br>
                                            <?php if(Session::get('message')): ?>
                                                <span id="message" class="text-center"> <?php echo e(Session::get('message')); ?></span>
                                            <?php endif; ?>
                                        </h5>
                                    </div>
                                    <div class="col-md-4  text-right" >
                                        <a class="" href="<?php echo e(route('about')); ?>">
                                            <strong> ADD NEW → </strong>
                                        </a>
                                    </div>


                                </div>


                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-striped table-responsive-md btn-table">

                                    <thead>
                                    <tr>
                                        <th>SL</th>

                                        <th>Address</th>
                                        <th>Email</th>
                                        <th>Mobile</th>


                                        <th></th>
                                    </tr>
                                    </thead>

                                    <tbody>

                                    <?php ( $i = 1); ?>
                                    <?php if(!empty($all_infos)): ?>

                                        <?php $__currentLoopData = $all_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($i++); ?></th>

                                                <td><?php echo e($category->address); ?></td>
                                                <td><?php echo e($category->email); ?></td>
                                                <td><?php echo e($category->mobile); ?></td>


                                                <td>
                                                    
                                                    &nbsp;
                                                    <a class="btn-floating btn-sm btn-danger ts-delete-al"  data-target="#info_delete" data-toggle="modal" onclick="delete_info(<?php echo e($category->id); ?>)"  title="Delete"><i class="fas fa-times"></i></a>

                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    </tbody>

                                </table>
                            </div>
                        </div>

                    </div>
                    <div class="row " style="margin: 10px">
                        <div class="col-12 float-right">
                            <?php echo e($all_infos->links()); ?>

                        </div>
                    </div>
                    <!-- /.col-md-6 -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>



    <div class="modal fade " id="info_delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="exampleModalLabel" style="font-family: Algerian;">Confirm Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="text-align: center">
                    <img src="<?php echo e(asset('img/alert-icon.png')); ?> " style="height: 100px;width: auto;text-align: center">
                </div>
                <div class="modal-body" style="text-align: center">
                    <h3 style="text-align: center">Are You Sure????</h3>
                </div>
                <div class="modal-footer" >

                    <a type="button" class="btn btn-danger btn-sm" id="del">Yes</a>
                </div>
            </div>
        </div>


    </div>


<?php $__env->stopSection(); ?>

<script>
    function delete_info(id) {
        $('#del').attr("href", "/del_info/" + id)
    }
</script>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/admin/Web/info_list.blade.php ENDPATH**/ ?>