<!doctype html>

<html class="no-js"  lang="en">

<?php echo $__env->make('front_end.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body onload="fetchBookmarks()">


<?php echo $__env->make('front_end.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('book'); ?>

<?php echo $__env->make('front_end.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('front_end.include.fscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>


</html>
<?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/front_end/book_master.blade.php ENDPATH**/ ?>