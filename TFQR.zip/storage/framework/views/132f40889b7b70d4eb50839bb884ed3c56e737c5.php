<?php $__env->startSection('title'); ?>
    ADMIN HOME
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div id="load"></div>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark"></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>

                            <li class="breadcrumb-item active"></li>

                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->

        <div class="content">
            <div class="container-fluid">
                <div class="row">

                </div>
                <div class="row">


                    <!-- /.col-md-6 -->
                    <div class="col-lg-2"></div>
                    <div class="col-lg-8">

                        <div class="card card-dark">
                            <div class="card-header">
                                <div class="row">

                                    <div class="col-md-12">
                                        <h5 class="text-center dynamic_name" >
                                            CREATE A NEW AYAH
                                            <br>
                                            <?php if(Session::get('message')): ?>
                                                <span id="" class="text-center"> <?php echo e(Session::get('message')); ?></span>
                                            <?php endif; ?>
                                        </h5>
                                    </div>

                                </div>


                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">

                                        <div class="form-group">
                                            <div class="form-check " id="update_ayah_record">
                                                <input type="checkbox" class="form-check-input surha_record" id="materialUnchecked" name="check">
                                                <label class="form-check-label" for="materialUnchecked">Update record from existing surah details </label>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="row add_new_ayah_form">
                                    <form action="<?php echo e(url('/save_ayah')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" name="key" value="new_ayah" hidden>
                                        <div class="row">

                                            <div class="col-12">
                                                <table class="table">
                                                    <thead>


                                                    </thead>
                                                    <tbody>

                                                    <tr>
                                                        <td>
                                                            Surah
                                                        </td>
                                                        <td>
                                                            <div class="form-group">


                                                                <select class="browser-default custom-select" name="surah_no" id="surah_no" required >
                                                                    <option value="" disabled selected>Select Surah</option>
                                                                    <?php if(!empty($all_surahs)): ?>
                                                                        <?php $__currentLoopData = $all_surahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_surah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($all_surah->taf_surah_id); ?>"><?php echo e($all_surah->taf_surah_name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>

                                                                </select>


                                                            </div>
                                                        </td>
                                                        <td>Ayah No</td>
                                                        <td> <input type="number" name="ayah_no" id="ayah_no" class="form-control"></td>
                                                    </tr>

                                                    <tr>
                                                        <td>Ayah Text</td>
                                                        <td colspan="4">

                                                            <textarea type="text" rows="2" class="form-control" id="ayah_text" name="ayah_text"></textarea></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Token No</td>
                                                        <td>
                                                            <input type="number" name="token_no" id="token_no" class="form-control">
                                                        </td>
                                                        <td><label for="token_expl_no"></label>Token Expl No </td>
                                                        <td>
                                                            <input type="number" name="token_expl_no" id="token_expl_no" class="form-control">
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <td>Ayah Translation</td>
                                                        <td colspan="4">
                                                            <textarea type="text" rows="2" class="form-control" id="ayah_translation" name="ayah_translation"></textarea>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Ayah Explanation</td>
                                                        <td colspan="4">
                                                        <textarea type="text" rows="3" class="form-control" id="ayah_explanation" name="ayah_explanation">

                                                        </textarea>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            Select Image
                                                        </td>
                                                        <td colspan="3">
                                                            <div class="form-group">


                                                                <select class="browser-default custom-select" name="image">
                                                                    <option value="" disabled selected>Choose An Image</option>
                                                                    <?php if(!empty($all_images)): ?>
                                                                        <?php $__currentLoopData = $all_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($all_image->image); ?>" name="image" class="rounded-circle">
                                                                                <?php echo $all_image->image_name; ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>


                                                                </select>



                                                            </div>
                                                        </td>

                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col-12 text-right">
                                                <button type="submit" class="btn btn-dark btn-rounded btn-sm">Add New Records</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <div class="row update_record_form">
                                    <form action="<?php echo e(url('/save_ayah')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" name="key" value="old_ayah" hidden>
                                        <div class="row">

                                            <div class="col-12">
                                                <table class="table">
                                                    <thead>


                                                    </thead>
                                                    <tbody>

                                                    <tr>
                                                        <td>
                                                            Surah
                                                        </td>
                                                        <td>
                                                            <div class="form-group">


                                                                <select class="browser-default custom-select" name="ex_surah_no" id="ex_surah_no" onchange="getAyahs(this)" required >
                                                                    <option value="" disabled selected>Select Surah</option>
                                                                    <?php if(!empty($all_surahs)): ?>
                                                                        <?php $__currentLoopData = $all_surahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_surah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($all_surah->taf_surah_id); ?>"><?php echo e($all_surah->taf_surah_name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </select>


                                                            </div>
                                                        </td>
                                                        <td>Ayah No</td>
                                                        <td>
                                                            <div class="form-group">


                                                                <select class="browser-default custom-select" name="ex_ayah_id" id="ex_ayah_no"  required >
                                                                    <option value="" disabled selected>Select Ayah No</option>

                                                                </select>


                                                            </div>
                                                        </td>
                                                    </tr>


                                                    <tr>
                                                        <td>Token No</td>
                                                        <td>
                                                            <input type="number" name="token_no" id="ex_token_no" class="form-control" required>
                                                        </td>
                                                        <td><label for="token_expl_no"></label>Token Expl No </td>
                                                        <td>
                                                            <input type="number" name="token_expl_no" id="token_expl_no" class="form-control">
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <td>Ayah Translation</td>
                                                        <td colspan="4">
                                                            <textarea type="text" rows="2" class="form-control" id="ayah_translation" name="ayah_translation"></textarea>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Ayah Explanation</td>
                                                        <td colspan="4">
                                                        <textarea type="text" rows="3" class="form-control" id="ayah_explanation" name="ayah_explanation">

                                                        </textarea>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>

                                                            Select Image
                                                        </td>
                                                        <td colspan="3">
                                                            <div class="form-group">


                                                                <select class="browser-default custom-select" name="image">
                                                                    <option value="" disabled selected>Choose your option</option>
                                                                    <?php if(!empty($all_images)): ?>
                                                                        <?php $__currentLoopData = $all_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($all_image->image); ?>" name="image" class="rounded-circle">
                                                                                <?php echo $all_image->image_name; ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>


                                                                </select>



                                                            </div>
                                                        </td>

                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col-12 text-right">
                                                <button type="submit" class="btn btn-dark btn-rounded btn-sm">Add New Records</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div>
                            <!-- /.card-body -->
                        </div>

                    </div>
                    <!-- /.col-md-6 -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/admin/Surah/add_ayah.blade.php ENDPATH**/ ?>