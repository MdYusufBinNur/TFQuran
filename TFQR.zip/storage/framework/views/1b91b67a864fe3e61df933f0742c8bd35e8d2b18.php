<?php $__env->startSection('title'); ?>
    ADMIN HOME
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    
    <div class="content-wrapper">
        <div class="register-box">
            
            
            

            <div class="card register-box-body">
                <p class="login-box-msg"><strong>Register a new membership</strong></p>

                <?php if(Session::get('confirm_message')): ?>
                    <h4 style="text-align: center" id="msg"><?php echo e(Session::get('confirm_message')); ?></h4>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('register_editors')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group has-feedback">
                        <label for="name" class="col-form-label"><?php echo e(__('Name')); ?></label>

                        <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                        <?php if($errors->has('name')): ?>
                            <span class="glyphicon glyphicon-envelope form-control-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group has-feedback">
                        <label for="email" class="col-form-label "><?php echo e(__('E-Mail Address')); ?></label>


                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                        <?php if($errors->has('email')): ?>
                            <span class="glyphicon glyphicon-envelope form-control-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                        <?php endif; ?>


                    </div>
                    <div class="form-group has-feedback">

                        <label for="password" class="col-form-label"><?php echo e(__('Password')); ?></label>


                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="glyphicon glyphicon-lock form-control-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>

                    </div>
                    <div class="form-group has-feedback">
                        <label for="password-confirm" class="col-form-label"><?php echo e(__('Confirm Password')); ?></label>


                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>

                        <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="checkbox icheck">

                            </div>
                        </div>
                        <!-- /.col -->
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary btn-block btn-flat" style="color: #ffffff;">
                                <?php echo e(__('Register')); ?>

                            </button>

                        </div>
                        <!-- /.col -->
                    </div>
                </form>


                
            </div>
            <!-- /.form-box -->
        </div>
    </div>



    <!-- Central Modal Small -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/admin/editors/editor.blade.php ENDPATH**/ ?>