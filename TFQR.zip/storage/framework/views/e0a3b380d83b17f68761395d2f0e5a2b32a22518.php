<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>SAIMOOM DIGITAL LIBRARY</title>

    <link rel=icon type=image/png sizes=32x32 href="<?php echo e(asset('img/quran.png')); ?>">
    
    
    
    
    
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('pro/css/mdb.min.css')); ?>">


    <style>
        #load{
            width:100%;
            height:100%;
            position:fixed;
            z-index:9999;
            background:url("https://www.creditmutuel.fr/cmne/fr/banques/webservices/nswr/images/loading.gif") no-repeat center center rgba(0,0,0,0.25)
        }

    </style>

    
</head>
<?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/admin/includes/head.blade.php ENDPATH**/ ?>