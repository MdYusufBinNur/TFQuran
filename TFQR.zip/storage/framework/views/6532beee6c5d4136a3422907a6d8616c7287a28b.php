<?php $__env->startSection('body'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark"></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>

                            <li class="breadcrumb-item active">Editor List</li>

                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->

        <div class="content">
            <div class="container-fluid">
                <div class="row">

                </div>
                <div class="row">


                    <!-- /.col-md-6 -->
                    <div class="col-lg-2"></div>
                    <div class="col-lg-8">

                        <div class="card card-dark">
                            <div class="card-header">
                                <div class="row">

                                    <div class="col-md-8">
                                        <h5 class="text-left" >
                                            CREATE A NEW BOOK
                                            &nbsp &nbsp
                                            <?php if(Session::get('message')): ?>
                                                <span id="message" class="text-center"> <?php echo e(Session::get('message')); ?></span>
                                            <?php endif; ?>
                                        </h5>
                                    </div>
                                    <div class="col-md-4  text-right" >
                                        <a class="" href="<?php echo e(route('book_list')); ?>">
                                            <strong> BOOK LIST → </strong>
                                        </a>
                                    </div>


                                </div>


                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <form role="form" action="<?php echo e(route('add_book')); ?>" method="POST" enctype="multipart/form-data">
                                    <!-- text input -->

                                    <?php echo csrf_field(); ?>
                                    <div class="row">

                                        <div class="col-12">
                                            <div class="form-group">
                                                <label>Book Name</label>
                                                <input type="text" class="form-control" placeholder="Enter Book name" id="book_name" name="book_name" required>
                                            </div>
                                        </div>

                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Author</label>
                                                <select class="browser-default custom-select" name="author_name" id="author_name">
                                                    <option selected>Select Author</option>

                                                    <?php if(!empty($authors)): ?>
                                                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($author->id); ?>"><?php echo e($author->author_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                    
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Publisher</label>
                                                <select class="browser-default custom-select" name="publisher_name" id="publisher_name">
                                                    <option selected>Select Publisher</option>
                                                    <?php if(!empty($publishers)): ?>
                                                        <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($publisher->id); ?>"><?php echo e($publisher->publisher_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Languages</label>
                                                <select class="browser-default custom-select" name="language_name" id="language_name">
                                                    <option selected>Select Language</option>
                                                    <option value="Bengali">Bengali</option>
                                                    <option value="English">English</option>
                                                    <option value="Arabic">Arabic</option>

                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-6">
                                            <div class="form-group">

                                                        <select id="category_name" class="mdb-select md-form" multiple searchable="Search for..." name="category_name[]" >
                                                            <option value="" disabled selected>Select Category</option>
                                                            <?php if(!empty($categories)): ?>
                                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </select>


                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Topics Name</label>
                                                <input type="text" class="form-control" placeholder="Topics" id="topics_name" name="topics_name" >
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Book Type</label>

                                                    <select class="browser-default custom-select" name="book_type" id="book_type" required>
                                                        <option value="" disabled selected>Select Book Types</option>
                                                        <?php if(!empty($booktypes)): ?>
                                                            <?php $__currentLoopData = $booktypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booktype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($booktype->book_type); ?>"><?php echo e($booktype->book_type); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                        

                                                    </select>


                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <div class="file-field">
                                                    <div class="btn btn-teal btn-sm btn-rounded float-left">
                                                        <span>Choose files</span>
                                                        <input type="file" name="image" >
                                                    </div>
                                                    <div class="file-path-wrapper">
                                                        <input class="file-path validate form-control"  type="text" placeholder="Upload one or more files" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="row">
                                        <div class="col-12 text-right">
                                            <div class="form-group">
                                                <button class="btn btn-dark btn-sm btn-rounded" type="submit">Create</button>
                                            </div>

                                        </div>
                                    </div>

                                </form>
                            </div>
                            <!-- /.card-body -->
                        </div>


                    </div>
                    <!-- /.col-md-6 -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/admin/Books/add_new_book.blade.php ENDPATH**/ ?>