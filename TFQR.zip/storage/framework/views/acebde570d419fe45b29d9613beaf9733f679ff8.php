<?php $__env->startSection('styles'); ?>
    <style>
        .trans{
            display: none;
        }
    </style>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('book'); ?>
    <div class="new-book-area pb-100" style="padding: 20px;">

        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="card">
                        <div class="card-body">

                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="section-title bt text-center pt-50 mb-10 section-title-res"  >
                                        <?php if(!empty($name)): ?>
                                            <h2 style="background-color: #FFFCF4;color: #8e8131"><i class="fa fa-question-circle-o" id="suraa_name"></i><strong style="font-family: Kalpurush;"><?php echo e($name->surah_name); ?></strong></h2>

                                            <br>
                                            <a href="#" data-toggle="modal" data-target="#TafseerModal">
                                                <h4 ><i class="fa fa-question-circle-o" id="suraa_name"></i><strong>SEE TAFSIR → </strong></h4>
                                            </a>
                                            <input type="text" id="surahh_name" value="<?php echo e($name->surah_name); ?>" hidden readonly>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>


                            <div class="tab-content">
                                <div class="tab-pane active" id="th">


                                    <?php if(!empty($sura_descriptions)): ?>
                                        <?php ($i = 0); ?>


                                        <?php $__currentLoopData = $sura_descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sura_description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($sura_description->ayah_no == $i): ?>
                                                <div class="row">
                                                    <div class="col-xs-1 text-center">

                                                </div>
                                                    <div class="col-xs-9 text-right">

                                                        <h3 style="margin-left: 20px">
                                                            <strong>
                                                                <p class="text-justify" style="font-family: Kalpurush;">
                                                                    <?php echo e($sura_description->token_trans); ?>

                                                                    <a href="#?" onclick="explanation(<?php echo e($sura_description->taf_token_id); ?>)">
                                                                        <sup><?php echo e($sura_description->token_expl_no); ?></sup>
                                                                    </a>
                                                                </p>
                                                            </strong>

                                                        </h3>

                                                        
                                                            

                                                            




                                                            
                                                            
                                                                
                                                            

                                                        
                                                        

                                                </div>
                                                    <div class="col-xs-2 text-center">

                                                </div>

                                                </div>
                                                <div class="row">
                                                    <div class="col-xs-1 text-center">

                                                    </div>

                                                    <div class="col-xs-9 trans mr-2"  id="<?php echo e($sura_description->taf_token_id); ?>" style="text-align: justify;margin-left: 20px;  font-family: Kalpurush; font-size: 20px">
                                                        <u>
                                                            <p>
                                                                <strong style="text-underline: black">
                                                                    ব্যাখ্যা
                                                                </strong>
                                                            </p>
                                                        </u>
                                                        <?php echo $sura_description->token_expl; ?>

                                                        <br> <br>
                                                    </div>

                                                </div>
                                            <?php else: ?>
                                                <hr style="height: 1px;
                                                color: rgba(2,132,120,0.08);
                                                background-color: rgba(2,132,120,0.12);
                                                border: none;">

                                                <div class="row">

                                                    <div class="col-xs-1 text-center">
                                                        <h3  style="color: #028478">
                                                            <?php echo e($sura_description->taf_surah_id.':'.$sura_description->ayah_no); ?>

                                                        </h3>
                                                    </div>
                                                    <div class="col-xs-9 text-right">
                                                        <h2>
                                                            <strong class="" style="font-size: 40px;font-family: ”Droid Arabic Naskh”, serif;" >
                                                                
                                                                <?php echo e($sura_description->ayah_text); ?>

                                                            </strong>
                                                        </h2>

                                                        <br> <br> <br>

                                                        <h3 style="margin-left: 20px">

                                                            <strong>
                                                                <p class="text-justify" style="font-family: Kalpurush;">

                                                                    <?php echo e($sura_description->token_trans); ?>

                                                                    <a href="#?" onclick="explanation(<?php echo e($sura_description->taf_token_id); ?>)">
                                                                        <sup><?php echo e($sura_description->token_expl_no); ?></sup>
                                                                    </a>
                                                                </p>
                                                            </strong>

                                                        </h3>



                                                        
                                                            
                                                                
                                                                
                                                                

                                                            

                                                        

                                                    </div>
                                                    <div class="col-xs-2 text-center">
                                                        <a href="#?" class="btn btn-floating btn-dark" title="Bookmark" onclick="bookmark_this('<?php echo e($sura_description->taf_surah_id); ?>' ,'<?php echo e($sura_description->ayah_no); ?>')" >
                                                            <i class="fa fa-bookmark"></i>
                                                        </a>
                                                    </div>

                                                </div>

                                                <div class="row">
                                                    <div class="col-xs-1 text-center">

                                                    </div>
                                                    <div class="col-xs-9 trans mr-2"  id="<?php echo e($sura_description->taf_token_id); ?>" style="text-align: justify;margin-left: 20px;  font-family: Kalpurush; font-size: 20px">

                                                        <u>
                                                            <p>
                                                                <strong style="text-underline: black">
                                                                    ব্যাখ্যা
                                                                </strong>
                                                            </p>
                                                        </u>
                                                        <?php echo $sura_description->token_expl; ?>

                                                        <br> <br>

                                                    </div>
                                                </div>

                                                <?php ($i++); ?>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                            

                                                
                                                    
                                                        
                                                            
                                                                
                                                                
                                                                    
                                                                
                                                            
                                                        
                                                    
                                                

                                                
                                                
                                                    

                                                        
                                                            
                                                        

                                                    
                                                    
                                                



                                            
                                                

                                                
                                                    
                                                        
                                                            

                                                                
                                                                    
                                                                
                                                            
                                                            
                                                                
                                                                    
                                                                        
                                                                    
                                                                


                                                            
                                                        
                                                        
                                                        
                                                            
                                                                
                                                                    
                                                                        
                                                                        
                                                                            
                                                                        
                                                                    
                                                                
                                                            
                                                            
                                                        
                                                        
                                                            

                                                                
                                                                    
                                                                

                                                            
                                                        
                                                        
                                                    

                                                    
                                                        
                                                            
                                                        
                                                    
                                                

                                                
                                                
                                            

                                        
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal fade" id="TafseerModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                 aria-hidden="true">

                <!-- Change class .modal-sm to change the size of the modal -->
                <div class="modal-dialog modal-lg " role="document">

                        <div class="modal-content">
                            <div class="modal-header">
                                <?php if(!empty($name)): ?>
                                    <h4 class="modal-title w-100 text-center" id="myModalLabel"><strong><?php echo e($name->surah_name); ?></strong></h4>
                                <?php endif; ?>

                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">

                                <div class="row">
                                    <div class="col-12" style="text-align: justify; white-space: pre-line; font-family: Kalpurush; font-size: medium">

                                             <?php if(!empty($surah_intro)): ?>

                                                <?php echo $surah_intro->surah_intro; ?>

                                             <?php endif; ?>

                                    </div>
                                </div>

                            </div>

                        </div>


                </div>
            </div>

            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
                <div class="col-sm-6">

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_js'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('front_end.book_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/front_end/Surah/surah_details.blade.php ENDPATH**/ ?>