

    <div class="main-menu-area hidden-sm hidden-xs sticky-header-1" id="header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-sm-1"></div>

                <div class="col-sm-10 ">

                    <div class="menu-area">
                        <nav>
                            <ul>
                                <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a>

                                </li>

                                <li>
                                    <a href="#">Tafhemul Quran<i class="fa fa-angle-down"></i></a>

                                    <div class="mega-menu example-1 scrollbar-deep-purple bordered-deep-purple thin">

                                        <span>
											<?php $__currentLoopData = $surah_names_first; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                    <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</span>
                                        <span>
											<?php $__currentLoopData = $surah_name_second; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</span>
                                        <span>
											<?php $__currentLoopData = $surah_name_third; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</span>
                                        <span>
											<?php $__currentLoopData = $surah_name_fourth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</span>

                                    </div>
                                </li>

                                <li><a href="#">Books<i class="fa fa-angle-down"></i></a>

                                    <div class="mega-menu mega-menu-3  example-1 scrollbar-deep-purple bordered-deep-purple thin">


                                        <span>


                                            <?php $__currentLoopData = $book_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($loop->iteration % 2 ==0): ?>

                                                    <a href="<?php echo e(url('categorical_book_view/'.$book->book_type)); ?>" class="title"><?php echo e($book->book_type); ?></a>

                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                    </span>

                                        <span>
												    <?php $__currentLoopData = $book_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->iteration % 2 !=0): ?>
                                                    <a href="<?php echo e(url('categorical_book_view/'.$book->book_type)); ?>" class="title"><?php echo e($book->book_type); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</span>




                                    </div>
                                    
                                </li>

                                <li><a href="#">Authors<i class="fa fa-angle-down"></i></a>
                                    <div class="mega-menu mega-menu-3  example-1 scrollbar-deep-purple bordered-deep-purple thin">
                                        <span>

                                            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->iteration % 2 ==0): ?>
                                                    <a href="<?php echo e(url('book_by_author/'.$book->author_name)); ?>" class="title"><?php echo e($book->author_name); ?></a>
                                                <?php endif; ?>
                                                
                                                    
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                    </span>
                                        <span>
											<?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->iteration % 2 !=0): ?>

                                                    <a href="<?php echo e(url('book_by_author/'.$book->author_name)); ?>" class="title"><?php echo e($book->author_name); ?></a>
                                                    
                                                        
                                                    
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</span>
                                    </div>
                                </li>

                                <li>
                                    <a href="#?" data-toggle="modal" data-target="#message_modal">Contact Us</a>

                                </li>

                                <li>
                                    <a href="#">Bookmarks<i class="fa fa-angle-down"></i></a>
                                    <div class="sub-menu sub-menu-2  example-1 scrollbar-deep-purple bordered-deep-purple thin" >
                                        <ul id="bookmark_list">

                                        </ul>
                                    </div>
                                </li>

                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-lg-12">


                </div>
            </div>
        </div>
    </div>
    <!-- main-menu-area-end -->
    <!-- mobile-menu-area-start -->
    <div class="mobile-menu-area hidden-md hidden-lg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="mobile-menu">
                        <nav id="mobile-menu-active">
                            <ul id="nav">
                                <li>
                                    <a href="<?php echo e(url('/')); ?>">Home</a>
                                </li>

                                <li class="scrollbar-deep-purple bordered-deep-purple thin">
                                    <a href="#?">Tafheemul Quran</a>
                                    <ul>

                                                <?php $__currentLoopData = $surah_names_first; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <li>
                                                        <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>
                                                    </li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $surah_name_second; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <li>
                                                        <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>
                                                    </li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $surah_name_third; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <li>
                                                        <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>
                                                    </li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $surah_name_fourth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <li>
                                                        <a href="<?php echo e(url('surah_info/'.$book->id)); ?>" class="title"><?php echo e($book->id); ?> <?php echo e($book->surah_name); ?></a>
                                                    </li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                                <li><a href="#?">Books</a>
                                    <ul>
                                        <?php $__currentLoopData = $book_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                            <li>

                                                <a href="<?php echo e(url('categorical_book_view/'.$book->book_type)); ?>" class="title"><?php echo e($book->book_type); ?></a>
                                            </li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                                <li><a href="#?">Authors</a>
                                    <ul>
                                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li>
                                                    <a href="<?php echo e(url('book_by_author/'.$book->author_name)); ?>" class="title"><?php echo e($book->author_name); ?></a>
                                                </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                                <li><a href="#?">Publishers</a>
                                    <ul>
                                        <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <li>
                                                <a href="#" class="title"><?php echo e($book->publisher_name); ?></a>
                                            </li>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                                <li>
                                    <a href="#?" class="example-1 scrollbar-deep-purple bordered-deep-purple thin">Bookmarks</a>
                                    <ul id="bookmark_listt">


                                    </ul>
                                </li>

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- mobile-menu-area-end -->

</header>

<?php /**PATH C:\xampp\htdocs\TFQuran\resources\views/front_end/include/header.blade.php ENDPATH**/ ?>