<?php

use Faker\Generator as Faker;

$factory->define(App\Booktype::class, function (Faker $faker) {
    return [
        //
    ];
});
