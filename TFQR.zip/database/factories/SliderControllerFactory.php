<?php

use Faker\Generator as Faker;

$factory->define(App\SliderController::class, function (Faker $faker) {
    return [
        //
    ];
});
