<?php

use Faker\Generator as Faker;

$factory->define(App\TafsirImage::class, function (Faker $faker) {
    return [
        //
    ];
});
