<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booktype extends Model
{
    protected $fillable = ['book_type'];
}
