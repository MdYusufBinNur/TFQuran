<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class taf_token extends Model
{
    public $timestamps = false;
    protected $fillable = ['ayah_no'];
}
