<?php

namespace App\Http\Controllers;

use App\taf_token;
use Illuminate\Http\Request;

class TafTokenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\taf_token  $taf_token
     * @return \Illuminate\Http\Response
     */
    public function show(taf_token $taf_token)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\taf_token  $taf_token
     * @return \Illuminate\Http\Response
     */
    public function edit(taf_token $taf_token)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\taf_token  $taf_token
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, taf_token $taf_token)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\taf_token  $taf_token
     * @return \Illuminate\Http\Response
     */
    public function destroy(taf_token $taf_token)
    {
        //
    }
}
