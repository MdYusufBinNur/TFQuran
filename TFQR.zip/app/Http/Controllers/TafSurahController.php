<?php

namespace App\Http\Controllers;

use App\taf_surah;
use Illuminate\Http\Request;

class TafSurahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\taf_surah  $taf_surah
     * @return \Illuminate\Http\Response
     */
    public function show(taf_surah $taf_surah)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\taf_surah  $taf_surah
     * @return \Illuminate\Http\Response
     */
    public function edit(taf_surah $taf_surah)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\taf_surah  $taf_surah
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, taf_surah $taf_surah)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\taf_surah  $taf_surah
     * @return \Illuminate\Http\Response
     */
    public function destroy(taf_surah $taf_surah)
    {
        //
    }
}
