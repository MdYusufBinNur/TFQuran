<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class taf_ayah extends Model
{
    public $timestamps = false;
}
