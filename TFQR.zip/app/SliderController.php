<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderController extends Model
{
    protected $guarded = array();
}
