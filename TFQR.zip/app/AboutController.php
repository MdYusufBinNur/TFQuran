<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AboutController extends Model
{
    protected $guarded = array();
}
