<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        @MdYsufBinNur
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2014-2018 <a href="https://tech-bari.com" target="_blank">Tech-Bari</a>.</strong> All rights reserved.
</footer>


