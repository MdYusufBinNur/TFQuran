

<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="contact-form">
        <h3><i class="fa fa-envelope-o"></i>Leave a Message</h3>
        <form id="contact-form" action="http://demo.devitems.com/koparion-v2/koparion/mail.php" method="post">
            <div class="row">
                <div class="col-lg-6">
                    <div class="single-form-3">
                        <input name="name" type="text" placeholder="Name">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="single-form-3">
                        <input name="email" type="email" placeholder="Email">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="single-form-3">
                        <input name="subject" type="text" placeholder="Subject">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="single-form-3">
                        <textarea name="message" placeholder="Message"></textarea>
                        <button class="submit" type="submit">SEND MESSAGE</button>
                    </div>
                </div>
            </div>
        </form>
        <p class="form-messege"></p>
    </div>
</div>
